#!/bin/sh

#####################################
# This script copy the Front End    #
# to the /var/www/html folder       #
#####################################

sudo service lighttpd stop
sudo cp -r static /var/www/html
sudo cp index.html /var/www/html
sudo service lighttpd start


