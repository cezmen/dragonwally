#!/bin/sh

# run_api.sh


nohup python DragonWallyAPI.py > dragon.log 2>&1 &


