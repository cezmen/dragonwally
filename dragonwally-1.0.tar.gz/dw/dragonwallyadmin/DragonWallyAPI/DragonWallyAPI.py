import os
from os.path import join, dirname, realpath, isfile
from flask import Flask, jsonify, render_template, request, Response
from flask_cors import CORS
from werkzeug.utils import secure_filename

from aws_helpers import AwsHelper
from camera import Camera


# Iniciando a aplicacao do micro-framework
app = Flask(__name__)

# Configurando Cross Origin Resource Sharing (CORS) para que as chamadas de outras origem sejam permitidas
CORS(app)

# Instanciando o AwsHelper para gerenciar os recursos na Amazon
aws = AwsHelper()

# Declarando o caminho para upload de imagens que irao compor a colecao de faces conhecidas
known_people_path = join(dirname(realpath(__file__)), 'static', 'known-people')

# Configurando o caminho default para upload das imagens
aws.set_faces_path(known_people_path)

cam = Camera()


def gen(camera,mode=0):
    while True:
        frame = camera.get_frame() if (mode==0) else camera.get_composed_frame()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')


@app.route('/camera/composed/stream')
def video_composed_feed():
    global cam
    return Response(gen(cam,mode=1),
                    mimetype='multipart/x-mixed-replace; boundary=frame')
    

@app.route('/camera/stream')
def video_feed():
    global cam
    return Response(gen(cam),
                    mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/camera/photo')
def take_photo():
    global cam
    return cam.take_photo()


@app.route('/camera/release')
def release_camera():
    global cam
    cam.__del__()
    return 'Camera released'


@app.route('/upload')
def show_upload():
    return render_template('upload.html')


@app.route('/uploader', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        f = request.files['file']
        filename = secure_filename(f.filename)

        face_name = request.form.get('face')
        camera_toggle = request.form.get('camera')
        camera_photo = request.form.get('photo')

        if not isfile(join(known_people_path, filename)):
            filename = secure_filename(face_name) + '.jpg'
            if camera_toggle is None:
                f.save(join(known_people_path, filename))
            else:
                os.rename(join(dirname(realpath(__file__)), camera_photo),
                          join(known_people_path, filename))
            aws.upload_face_to_s3(filename)
            # aws.add_faces_to_collection()
            aws.add_face_to_collection(filename)
            os.remove(join(known_people_path, filename))

        return 'File uploaded successfully'


@app.route('/faces')
def list_faces():
    return jsonify(aws.list_faces_in_collection())


@app.route('/face/delete/<faceid>/<facekey>', methods=['GET', 'POST'])
def delete_face(faceid, facekey):
    resp = aws.delete_face_in_collection(face=faceid)
    if resp['ResponseMetadata']['HTTPStatusCode'] == 200:
        resp = aws.delete_face_in_s3(face=facekey)
    return jsonify(resp)


@app.route('/faces/unknown')
def list_unknown_faces():
    return jsonify(aws.list_unknown_faces_in_s3())


@app.route('/face/unknown/delete/<facekey>', methods=['GET', 'POST'])
def delete_unknown_face(facekey):
    resp = aws.delete_face_in_s3(face=facekey, bucket=aws.unknown_bucket_faces)
    return jsonify(resp)


@app.route('/sync')
def sync_s3_with_collection():
    return jsonify(aws.add_faces_to_collection())


@app.route('/speech/<facename>/<message>')
def get_speech(message, facename):
    resp = aws.synthetize_speech(message.format(name=facename))
    return Response(resp['AudioStream'].read(),
                    mimetype="audio/mpeg")


@app.route('/speech/raw/<facename>/<message>')
def get_raw_speech(message, facename):
    resp = aws.synthetize_speech(message.format(name=facename))
    return resp


if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=False, threaded=True)
