import logging
import os
from os.path import join, dirname, realpath, isfile
import cv2
import time

####################
# new imports here #
####################
from PIL import Image
import numpy as np

logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-10s) %(message)s',
                    )


class Camera(object):
    def __init__(self):
        self.video = cv2.VideoCapture(3)
        self.frame = None

    def __del__(self):
        self.video.release()

    #######################
    # swap Red and Blue   #
    #######################
    def color_swap(self, img):
        red, green, blue = img.T
        img = np.array([blue, green, red]).T
        return img

    ######################
    # save image to file #
    ######################
    def save_image(self, img, path):
        im = Image.fromarray(self.color_swap(np.array(img)))
        im.save(path)

    def get_frame(self):
        time.sleep(.25)
        success, image = self.video.read()
        self.frame = image
        # We are using Motion JPEG, but OpenCV defaults to capture raw images,
        # so we must encode it into JPEG in order to correctly display the
        # video stream.
        ret, jpeg = cv2.imencode('.jpg', image)
        return jpeg.tobytes()

    def get_composed_frame(self):
	image = cv2.imread("../../dragonwally/dwmainimage.jpg")
        ret, jpeg = cv2.imencode('.jpg', image)
        return jpeg.tobytes()


    def take_photo(self):
        ###################################
        # Get a copy of the current frame #
        ###################################
        image = self.frame
        if image is not None:
            ts = int(time.time())
            file = 'new-photo_%s.jpg' % ts
            urlpath = join('static', 'photos', file)
            filename = join(dirname(realpath(__file__)), urlpath)
            if isfile(filename):
                os.remove(filename)
            ###############
            # store image #
            ###############
            self.save_image(image, filename)
            return urlpath
        else:
            return ""
