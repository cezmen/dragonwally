#!/bin/sh

sudo media-ctl -d /dev/media1 -l '"msm_csiphy0":1->"msm_csid0":0[1],"msm_csid0":1->"msm_ispif0":0[1],"msm_ispif0":1->"msm_vfe0_rdi0":0[1]'

sudo media-ctl -d /dev/media1 -V '"ov5645 1-0076":0[fmt:UYVY2X8/1920x1080],"msm_csiphy0":0[fmt:UYVY2X8/1920x1080],"msm_csid0":0[fmt:UYVY2X8/1920x1080],"msm_ispif0":0[fmt:UYVY2X8/1920x1080],"msm_vfe0_rdi0":0[fmt:UYVY2X8/1920x1080]'



sudo media-ctl -d /dev/media1 -l '"msm_csiphy1":1->"msm_csid1":0[1],"msm_csid1":1->"msm_ispif1":0[1],"msm_ispif1":1->"msm_vfe0_rdi1":0[1]'

sudo media-ctl -d /dev/media1 -V '"ov5645 1-0074":0[fmt:UYVY2X8/1920x1080],"msm_csiphy1":0[fmt:UYVY2X8/1920x1080],"msm_csid1":0[fmt:UYVY2X8/1920x1080],"msm_ispif1":0[fmt:UYVY2X8/1920x1080],"msm_vfe0_rdi1":0[fmt:UYVY2X8/1920x1080]'


