#!/bin/sh

sudo media-ctl -d /dev/media1 -r



