#! /bin/sh


# to ensure that the image sensors are properly connected...

sudo media-ctl -d /dev/media1 -p


