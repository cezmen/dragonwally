####################################
# DWble.py                         #
####################################
from threading import Thread
from bluepy.btle import DefaultDelegate
from bluepy.btle import Peripheral, UUID
from bluepy.btle import BTLEException


##########################
# Peripheral Delegate    #
##########################
class MyDelegate(DefaultDelegate):
    def __init__(self):
        DefaultDelegate.__init__(self)

    def handleNotification(self, cHandle, data):
        # ... perhaps check cHandle
        # ... process 'data'
        pass

#############################
# convert a Vetor to String #
#############################
def makestring(bytes):
    return "".join(map(chr,bytes))


class DWble:
   def __init__(self):
	self.stopped = True
	self.pending = False
	self.request_write = False
	self.write_success = False

   def start(self):
	self.stopped = False
	Thread(target=self.update,args=()).start()
	return self

   def update(self):
	while True:
	   if (self.stopped):
		return 
	   # do something
	   if (self.request_write):
              self.write_success = self.execute_write(self.target_value)
	      self.request_write = False
	      self.pending = False
	      
   def stop(self):
	self.stopped = True

   def set_target(self,addr,s_uuid,ch_uuid):
	self.device_address = addr 
	self.service_uuid = s_uuid
	self.characteristic_uuid = ch_uuid

   def set_defaults(self):
        self.set_target("34:81:f4:07:db:86",
		        '59c88760-5364-11e7-b114-b2f933d5fe66',
		        '59c88d6e-5364-11e7-b114-b2f933d5fe66')
	
   def write(self,value):
	if (not self.pending):
	  self.target_value = value
	  self.request_write = True
	  self.pending = True
	  return True
	else:
	  return False

   def is_successfull(self):
	if (self.pending):
           return False
	else:
	   return self.write_success

   def is_pending(self):
	return (self.pending)

   def execute_write(self,value):
	print(value)
	success = False 
	for i in range (0,2):  # two attempts
   	  try:
	      p = Peripheral(self.device_address).withDelegate(MyDelegate())
  	      serv = p.getServiceByUUID(self.service_uuid)
 	      characteristics = serv.getCharacteristics()
 	      for ch in characteristics:
                if (UUID(ch.uuid).getCommonName() == self.characteristic_uuid):
                   ch.write(makestring(value))
		   success = True
                   break
	      p.disconnect()
	  except BTLEException:
   	      # treat exception here
	      print("BTLE Exception")
	      pass

	return success


