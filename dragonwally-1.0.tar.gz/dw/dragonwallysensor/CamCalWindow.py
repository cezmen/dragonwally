#!/usr/bin/env python

import pygtk
pygtk.require('2.0')
import gtk
import pickle
import os

def scale_set_default_values(scale):
        scale.set_update_policy(gtk.UPDATE_CONTINUOUS)
        scale.set_digits(1)
        scale.set_value_pos(gtk.POS_LEFT)
        scale.set_draw_value(True)


class CameraCalibrationWindow:

	def load_parameters(self):
		if (os.path.isfile("camera.parameters")):
			self.parameters = pickle.load(open("camera.parameters","rb"))
		else:
			self.parameters = { "xoff1":"0","yoff1":"0","xoff2":"0","yoff2":"0"}


	def save_parameters(self):
                self.parameters['xoff1'] = self.entry[0].get_text()
                self.parameters['yoff1'] = self.entry[1].get_text()
                self.parameters['xoff2'] = self.entry[2].get_text()
                self.parameters['yoff2'] = self.entry[3].get_text()
		pickle.dump(self.parameters,open("camera.parameters","wb"))

	def get_parameter(self,key):
		return self.parameters[key]
 
	def enter_callback(self,widget,entry):
		self.save_parameters()

		for fn in self.callbacks:
		   fn(self.get_parameter('xoff1'),self.get_parameter('yoff1'),
		      self.get_parameter('xoff2'),self.get_parameter('yoff2'))

		self.hide()

	def cancel_callback(self,widget,entry):
		self.recoverValues()
		self.hide()

	def scale_changed_event(self,widget,data=None):
		if data != None:
		   i = int(data)
		   v = int(self.adj[i].get_value())
		   print("Value: %d" % v) 
		   self.entry[i].set_text(str(int(self.adj[i].get_value())))

	def entry_changed_event(self,widget,data=None):
		if data != None:
		   i = int(data)
		   t = self.entry[i].get_text()
		   
		   v = float(t) if len(t) else 0.0
		   self.adj[i].set_value(v)

	def show(self):
		self.window.show()
		
	def hide(self):
		self.window.hide()

	def subscribe(self,callback):
		self.callbacks.append(callback)

	def __init__(self):
		#callbacks
		self.callbacks = []

		self.entry = [0,0,0,0]
		self.adj   = [0,0,0,0]
                self.scale = [0,0,0,0]
		self.load_parameters()
		self.labels = ['X offset CAM1', 'Y offset CAM1', 'X offset CAM2', 'Y offset CAM2']
		self.values = [self.parameters['xoff1'],self.parameters['yoff1'],self.parameters['xoff2'],self.parameters['yoff2']]


		self.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
		self.window.set_decorated(False)
		# window.set_size_request(260,100)
		self.window.set_title("Camera Calibration")
		self.window.set_border_width(10)

		vbox = gtk.VBox(False,5)
		self.window.add(vbox)
		vbox.show()
		
		frame = gtk.Frame('Offsets')
		vboxf = gtk.VBox(False,5)
		frame.add(vboxf)
		vboxf.show()

		for i in range(0,4):
		   hbox = gtk.HBox(False,5)
		   vboxf.pack_start(hbox,True,True,0)
		   hbox.show()

		   # LABEL
		   label = gtk.Label(self.labels[i])
		   label.set_justify(gtk.JUSTIFY_LEFT)
		   hbox.pack_start(label,False,True,0)
		   label.show()

                   # TEXT
		   self.entry[i] = gtk.Entry()
		   self.entry[i].set_max_length(4)
		   self.entry[i].set_text(self.values[i])
		   self.entry[i].set_size_request(50,30)
		   self.entry[i].connect("changed",self.entry_changed_event,i)
		   hbox.pack_start(self.entry[i],False,True,5)
		   self.entry[i].show()
		
		   # SCALE
		   self.adj[i] = gtk.Adjustment(float(self.values[i]),0.0,170.0,1.0,10.0,10.0)
		   self.scale[i] = gtk.HScale(self.adj[i])
		   self.scale[i].set_size_request(320,30)
		   scale_set_default_values(self.scale[i])
		   self.scale[i].set_round_digits(0)
		   self.scale[i].connect("value-changed",self.scale_changed_event,i)
		   hbox.pack_start(self.scale[i],False,True,5)
		   self.scale[i].show()   
		
		vbox.pack_start(frame,True,True,0)
		frame.show()	

		hbox = gtk.HBox(False,5)
		hbox.show()
		button = gtk.Button(stock=gtk.STOCK_CANCEL)
		button.connect("clicked",self.cancel_callback,self)
		button.show()
		hbox.pack_start(button,True,True,5)		
		button = gtk.Button(stock=gtk.STOCK_OK)
		button.connect("clicked",self.enter_callback,self)
		button.show()
		hbox.pack_start(button,True,True,5)
		vbox.pack_start(hbox,False,True,0)

	def recoverValues(self):
		self.load_parameters()
		self.values = [self.parameters['xoff1'],
			       self.parameters['yoff1'],
                               self.parameters['xoff2'],
                               self.parameters['yoff2']]
		for i in range(0,4):
		   self.entry[i].set_text(self.values[i])

	def move(self,x,y):
		self.window.move(x,y)

	def setModal(self,parent):
		self.window.set_modal(True)
		self.window.set_transient_for(parent)

	def clrModal(self):
		self.window.set_modal(False)
		self.window.set_transient_for(None)

def main():
	gtk.main()
	return 0

if __name__ == "__main__":
	CameraCalibrationWindow().show()
	main()


