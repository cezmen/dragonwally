from os import listdir
from os.path import isfile, join, dirname, realpath
import boto3
from botocore.exceptions import ClientError


class AwsHelper:

    # Path to 'known faces' uploaded by web application
    faces_path = join(dirname(realpath(__file__)), 'KnownPersons', 'static', 'faces')

    # Rekognition Collection Name
    dragon_collection_name = 'knowpersons-collection'

    # S3 Bucket for 'known faces'
    default_bucket_name = 'dragon-contest'

    # S3 Bucket for 'unknown faces' detected by DragonWally
    unknown_bucket_faces = 'dragon-unknown-faces'

    # AWS API Objects
    rekog = boto3.client('rekognition')
    s3 = boto3.client('s3')
    polly = boto3.client('polly')
    s3_resource = boto3.resource('s3')

    def __init__(self):
        pass

    def set_faces_path(self, path):
        self.faces_path = path
        return self.faces_path

    # Create the collection in rekognition
    def create_collection(self):

        collections = self.rekog.list_collections()
        print("Checking for default collection ... ")

        for collection in collections["CollectionIds"]:
            if collection == self.dragon_collection_name:
                print("Collection already exists!\nNothing to do ... closing")
                exit()

        print("No collection found!")
        print("Creating the Know Persons Collection ... ")

        response = self.rekog.create_collection(
            CollectionId=self.dragon_collection_name
        )

        print(response)
        print("Closing")

    # Add all faces (known faces) to the default collection in rekognition
    def add_faces_to_collection(self):
        print("Adding faces to default collection")
        bucket = self.s3_resource.Bucket(self.default_bucket_name)

        print(bucket.name)
        faces = []
        for item in bucket.objects.all():
            face_name_id = item.key
            print(face_name_id)
            response = self.rekog.index_faces(
                CollectionId=self.dragon_collection_name,
                Image={
                    'S3Object': {
                        'Bucket': bucket.name,
                        'Name': face_name_id
                    }
                },
                ExternalImageId=face_name_id
            )
            faces.append(response)
            print(response)

        print("Closing")
        return faces

    # Add a face to default rekogtion collection
    def add_face_to_collection(self, face):
        response = self.rekog.index_faces(
            CollectionId=self.dragon_collection_name,
            Image={
                'S3Object': {
                    'Bucket': self.default_bucket_name,
                    'Name': face
                }
            },
            ExternalImageId=face
        )
        return response

    # List all faces in the default rekognition collection
    def list_faces_in_collection(self):
        response = self.rekog.list_faces(
            CollectionId=self.dragon_collection_name,
            MaxResults=20,
        )
        return response["Faces"]

    # Search for a face in default rekogtion collection
    def search_faceid_in_collection(self, faceId):
        response = []
        try:
            response = self.rekog.search_faces(
                CollectionId=self.dragon_collection_name,
                FaceId=faceId,
                MaxFaces=10,
                FaceMatchThreshold=50
            )
        except ClientError:
            pass
        return response

    # Delete a face from default rekognition collection
    def delete_face_in_collection(self, face):
        response = []
        try:
            response = self.rekog.delete_faces(
                CollectionId=self.dragon_collection_name,
                FaceIds=[
                    face
                ]
            )
        except ClientError:
            pass
        return response

    # Lista all unknown faces in S3 bucket
    def list_unknown_faces_in_s3(self):
        response = self.s3.list_objects(
            Bucket=self.unknown_bucket_faces
        )
        return response['Contents']

    # Upload all faces (known faces) to S3 bucket
    def upload_faces_to_s3(self):
        print("Getting all face images from default folder ... ")
        faces_list_images = [f for f in listdir(self.faces_path) if isfile(join(self.faces_path, f))]
        print("Uploading all imagens to S3 default bucket ... ")
        for face in faces_list_images:
            self.s3.upload_file(
                join(self.faces_path, face), self.default_bucket_name, face,
                ExtraArgs={'ACL': 'public-read'}
            )
            print(join(self.faces_path, face))
        print("Closing")

    # Upload a single face (known face) to S3 Bucket
    def upload_face_to_s3(self, face_image):
        self.s3.upload_file(
            join(self.faces_path, face_image), self.default_bucket_name, face_image,
            ExtraArgs={'ACL': 'public-read'}
        )

    # Delete a face in S3 Bucket
    def delete_face_in_s3(self, face, bucket=default_bucket_name):
        response = []
        try:
            print (bucket)
            response = self.s3.delete_object(
                Bucket=bucket,
                Key=face
            )
        except ClientError:
            pass
        return response

    # Search an unknown face in default rekognition1s collection
    def search_face_in_collection(self, path_to_image, face_image, threshold):
        print("Running face rekognition")
        print(join(path_to_image, face_image))
        response = self.s3.upload_file(
            join(path_to_image, face_image), self.unknown_bucket_faces, face_image,
            ExtraArgs={'ACL': 'public-read'}
        )
        response = self.rekog.search_faces_by_image(
             CollectionId=self.dragon_collection_name,
             FaceMatchThreshold=threshold,
             Image={
                 'S3Object': {
                     'Bucket': self.unknown_bucket_faces,
                     'Name': face_image
                 }
             },
             MaxFaces=1
         )
        return response

    def synthetize_speech(self, message):
        response = self.polly.synthesize_speech(
            OutputFormat='mp3',
            Text=message,
            VoiceId='Joey'
        )
        return response

# print("Recreating the collection in rekognition")
# response = rekog.delete_collection(
#     CollectionId=dragon_collection_name,
# )
# create_collection()

# print("Adding faces in collection from 'Known Faces' S3 Bucket")
# add_faces_to_collection()

# print("Listing faces in collection")
# list_faces_in_collection()

# print("Example of usage")
# image = 'DSC05694.JPG'
# resp = search_face_in_collection(join(dirname(realpath(__file__)), 'unknownImages'), image, 95)
# print(resp["FaceMatches"])
