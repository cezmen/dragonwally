#!/usr/bin/env python

import pygtk
pygtk.require('2.0')
import gtk
import pickle
import os

class RecognitionConfigurationWindow:

	def load_parameters(self):
                if (os.path.isfile("recognition.parameters")):
                        self.parameters = pickle.load(open("recognition.parameters","rb"))
                else:
                        self.parameters = { "recognition_mode":"0" }

        def save_parameters(self):
                self.parameters['recognition_mode'] = self.recognition_mode
                pickle.dump(self.parameters,open("recognition.parameters","wb"))

        def get_parameter(self,key):
                return self.parameters[key]

        def show(self):
                self.window.show()

        def hide(self):
                self.window.hide()

        def enter_callback(self,widget,entry):
                self.save_parameters()
                self.hide()

        def cancel_callback(self,widget,entry):
                self.recoverValues()
                self.hide()


	def callback_mode(self,widget,data=None):
		if (widget.get_active() == 1):
		  if data == "disabled":
		    self.recognition_mode = 0
		  elif data == "opencv":
		    self.recognition_mode = 1
		  elif data == "aws":
		    self.recognition_mode = 2

        def __init__(self):
		self.recognition_mode = 0 ;
		self.load_parameters()

		self.recognition_mode = self.get_parameter('recognition_mode')

		self.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
                self.window.set_decorated(False)
                # window.set_size_request(260,100)
                self.window.set_title("Recognition")
                self.window.set_border_width(10)

             	vbox = gtk.VBox(False,5)
                self.window.add(vbox)
                vbox.show()

		frame = gtk.Frame('Recognition Mode')
                vboxf = gtk.VBox(False,5)
                frame.add(vboxf)
                vboxf.show()

                
		button = gtk.RadioButton(None,"Disabled")
		button.connect("toggled",self.callback_mode,"disabled")
		button.set_active(self.recognition_mode == 0)
		vboxf.pack_start(button,True,True,2)
		button.show()

                button = gtk.RadioButton(button,"OpenCV")
                button.connect("toggled",self.callback_mode,"opencv")
                button.set_active(self.recognition_mode == 1)
                vboxf.pack_start(button,True,True,2)
                button.show()

                button = gtk.RadioButton(button,"AWS Rekognition")
                button.connect("toggled",self.callback_mode,"aws")
                button.set_active(self.recognition_mode == 2)
                vboxf.pack_start(button,True,True,2)
                button.show()


                vbox.pack_start(frame,True,True,0)
                frame.show()

                hbox = gtk.HBox(False,5)
                hbox.show()
                button = gtk.Button(stock=gtk.STOCK_CANCEL)
                button.connect("clicked",self.cancel_callback,self)
                button.show()
                hbox.pack_start(button,True,True,5)
                button = gtk.Button(stock=gtk.STOCK_OK)
                button.connect("clicked",self.enter_callback,self)
                button.show()
                hbox.pack_start(button,True,True,5)
                vbox.pack_start(hbox,False,True,0)

        def recoverValues(self):
                self.load_parameters()
                self.recognition_mode = self.parameters['recognition_mode']

        def move(self,x,y):
                self.window.move(x,y)

        def setModal(self,parent):
                self.window.set_modal(True)
                self.window.set_transient_for(parent)

        def clrModal(self):
                self.window.set_modal(False)
                self.window.set_transient_for(None)


def main():
        gtk.main()
        return 0

if __name__ == "__main__":
        RecognitionConfigurationWindow().show()
        main()


