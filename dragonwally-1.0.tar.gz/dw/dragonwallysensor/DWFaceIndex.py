#!/usr/bin/env python

class DragonWallyFaceIndex:

   def __init__(self):
      self.faceIndex = {
         '2e97d9fe-451a-56d6-856d-044694934bfd' : "JESSICA",
	 '7e08872c-08c0-5a17-a8b9-06a8173d9a85' : "CLEBER" ,
	 '6a3f3c46-c8aa-55d7-9410-94cbb2b0778a' : "PAUL" ,
	 '393e2c5d-f335-5658-8d7a-06bd8fd2798f' : "JOHN" ,
	 '27774f4d-72b2-5da3-96be-0a953b22d969' : "OLIVIA" ,
	 'e4e9fd5b-9752-5cd7-9252-55fe6904e6f5' : "CEZAR" ,
	 '1ed5cc63-b6b7-5243-bfe7-3877e5dddb42' : "BARACK" ,
	 'ffe0f2c7-39bc-5148-bb7c-4724c2aad25d' : "EMILY" ,
	 'd6e20bc4-066e-577d-9837-ca2ce006b2b3' : "EVANGELINE" ,
	 'd057053b-641b-5391-b6da-0b735a42611e' : "STEVE"}

   def getName(self,id):
        name = self.faceIndex.get(id)
	return name if (name != None) else id

   def getFullIndex(self):
	return self.faceIndex


