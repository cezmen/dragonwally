#!/bin/sh

##########################
# run DragonWally sensor #
##########################

./dragonwally.py


