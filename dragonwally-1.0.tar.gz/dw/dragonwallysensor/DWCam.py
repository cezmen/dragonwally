# import the necessary packages
from threading import Thread
import cv2

#
# src = CAM1 (src=0)  or CAM2 (src=1)
# mode = Thread Mode (mode=0) or Direct Read Mode (mode=1)
#
 
class DragonWallyCamera:
	def __init__(self, src=0, mode=0):
		# initialize the video camera stream and read the first frame
		# from the stream
		self.mode = mode
		self.stream = cv2.VideoCapture(src)
		(self.grabbed, self.frame) = self.stream.read()
 
		# initialize the variable used to indicate if the thread should
		# be stopped
		self.stopped = True
		self.xoff = 0 ;
		self.yoff = 0 ;
		self.margin = 0 ;
		self.Wmax = 1920
		self.Hmax = 1080 

 	def start(self):
                # start the thread to read frames from the video stream
		self.stopped = False
		if (self.mode == 0):
                	Thread(target=self.update, args=()).start()
		else:
			#do nothing
			pass
                return self

       	def update(self):
                # keep looping infinitely until the thread is stopped
                while True:
                        # if the thread indicator variable is set, stop the thread
                        if self.stopped:
                                return
                        # otherwise, read the next frame from the stream
                        (self.grabbed, self.frame) = self.stream.read()

	def read(self):
		if (self.mode == 1):
			# read the next frame from the stream
                	(self.grabbed, self.frame) = self.stream.read()
		else:
			#do nothing
			pass

		# return the frame most recently read
		h,w,c = self.frame.shape
		oh = h-2*self.margin
		ow = w-2*self.margin 
		oframe = self.frame[self.yoff:self.yoff+oh,self.xoff:self.xoff+ow]
		return oframe
 
	def stop(self):
		# indicate that the thread should be stopped
		self.stopped = True

	def setCalibration(self,x,y,m):
		self.xoff = x 
		self.yoff = y 
		self.margin = m

	def getDimensions(self):
		w = self.Wmax - 2 * self.margin
		h = self.Hmax - 2 * self.margin
		return (w,h)


