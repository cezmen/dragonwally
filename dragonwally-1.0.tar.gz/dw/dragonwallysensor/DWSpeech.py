#!/usr/bin/python

import aws_helpers as ah
import subprocess
from contextlib import closing

class DWSpeech:

   def __init__(self):
       self.api = ah.AwsHelper()
       self.audiofile = "dwspeech.mp3"
       self.tonefile = "tone12khz.mp3"

   def play (self,file):
       p = subprocess.Popen(["mpg123","-q",file])
       p.wait()

   def say(self,phrase):

       speech = self.api.synthetize_speech(phrase)

       if "AudioStream" in speech:
         with closing(speech["AudioStream"]) as stream:
            data = stream.read()
            fo = open(self.audiofile,"w+")
            fo.write(data)
            fo.close()
	    self.play(self.tonefile) # wake-up 12khz tone
            self.play(self.audiofile)


