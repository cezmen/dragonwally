#!/usr/bin/env python

# DWWindow - DragonWally Window

import pygtk
pygtk.require('2.0')
import gtk
import CamCalWindow
import RecogConfigWindow
from threading import Thread

######################
# DragonWally Window #
######################

class DragonWallyWindow:

	def callback(self,widget,data=None):
		print "Message : %s was pressed" % data

	def delete_event(self,widget,event,data=None):
		print("DWWindow quit")
		gtk.main_quit()
		return False

	def callbackCCWEnter(self,widget,data=None):
		self.ccw.move(260,260)
		self.ccw.setModal(self.window)
		self.ccw.show()

	def callbackCCWExit(self,xoff1,yoff1,xoff2,yoff2):	
		for fn in self.calibration_callbacks:
		   fn(xoff1,yoff1,xoff2,yoff2,140)
		self.ccw.clrModal()

	def callbackRCWEnter(self,widget,data=None):
		self.rcw.move(360,260)
		self.rcw.setModal(self.window)
		self.rcw.show()

	def callbackRCWExit(self,mode):
		self.rcw.clrModal()
	

	def __init__(self):
		self.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
		self.window.set_title("DragonWally")
		self.window.maximize()
		self.window.connect("delete_event",self.delete_event)
		self.window.set_border_width(0)
		table = gtk.Table(2,4,False)
		table.set_row_spacings(10)
		table.set_col_spacings(10)
		self.window.add(table)
		button = [0,0,0,0]
		button[0] = gtk.Button("QUIT")
		button[0].connect("clicked", lambda w:gtk.main_quit())
		table.attach(button[0],0,1,1,2,xoptions=gtk.FILL,yoptions=gtk.FILL)
		button[0].show()

		button[1] = gtk.Button("BLUETOOTH")
		table.attach(button[1],1,2,1,2,xoptions=gtk.FILL,yoptions=gtk.FILL)
		button[1].show()

                button[2] = gtk.Button("RECOGNITION")
                table.attach(button[2],2,3,1,2,xoptions=gtk.FILL,yoptions=gtk.FILL)
                button[2].show()
		self.rcw = RecogConfigWindow.RecognitionConfigurationWindow() 
		button[2].connect("clicked",self.callbackRCWEnter)

                button[3] = gtk.Button("CALIBRATE")
                table.attach(button[3],3,4,1,2,xoptions=gtk.FILL,yoptions=gtk.FILL)
                button[3].show()
		self.ccw = CamCalWindow.CameraCalibrationWindow()
		self.ccw.subscribe(self.callbackCCWExit)
		button[3].connect("clicked",self.callbackCCWEnter)
		self.calibration_callbacks = []

		self.image = gtk.Image()
		self.image.set_from_file("images/dragonwally-bkg-01.jpg") 
		table.attach(self.image,0,4,0,1,xoptions=gtk.FILL,yoptions=gtk.FILL)
		self.image.show()
		
		table.show()
		self.window.show()

		# initialize the variable used to indicate if the thread should
                # be stopped
		self.stopped = False 

	def loadImage(self,image):
		pixbuf = gtk.gdk.pixbuf_new_from_array(image,gtk.gdk.COLORSPACE_RGB,8)
		self.image.set_from_pixbuf(pixbuf)

	def subscribeCalibration(self,callback):
		self.calibration_callbacks.append(callback)

	def getCalibration(self):
		cal = (self.ccw.get_parameter('xoff1'),self.ccw.get_parameter('yoff1'),
                      self.ccw.get_parameter('xoff2'),self.ccw.get_parameter('yoff2'),
		      "140")
		return cal
		
	def start(self):
		gtk.threads_init()
		Thread(target=self.update,args=()).start()
		return self

	def update(self):
		gtk.main()
		self.stopped = True

	def stop(self):
		gtk.main_quit()
		self.stopped = True 

	def isRunning(self):
		return 1 if (self.stopped == False) else 0
	


