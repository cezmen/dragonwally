#! /usr/bin/python
# coding=UTF-8

##################
# dragonwally.py #
##################

import DWWindow
import DWLogic
import DWRecogLogic 
import DWble
import DWSpeech

previous_face_name = ""

flagDemoSpeech = False     # (activate Demo Speech or not)
flagDemoBLE = False        # (activate Demo BLE or not)

#############
# callbacks #
#############
def updateWindowImage(img):
	global dww 
	dww.loadImage(img)

def updateFace(img):
	global dwrl
	dwrl.request(img)

def updateCameraCalibration(xoff1,yoff1,xoff2,yoff2,margin):
	print("New Calibration Parameters")
	global dwl
	dwl.setCameraCalibration(xoff1,yoff1,xoff2,yoff2,margin)

def updateRecognition(name,id,similarity):
	global ble
	global speech
        global previous_face_name
	global flagDemoSpeech
	global flagDemoBLE


	print ("Recognition: %s %s %f" % (name,id,similarity))
	dwl.setSubtitle(1,"%s (%.0f%%)" % (name,similarity) if (len(name)) else "")
	####################
        # Demo BLE         #
        ####################
	if (flagDemoBLE):
	   if (name == "CEZAR") or (name == "BARACK") or (name=="PAUL") :
	      ble.write([0x00])  # leds ON
           else:
	      ble.write([0x18])  # leds OFF

        ####################
        # Demo Speech      #
        ####################
	if (flagDemoSpeech):
	   if (previous_face_name != name):
              speech.say("%s" % (name))
	   previous_face_name = name

############### 
# main window #
###############
dww = DWWindow.DragonWallyWindow()
dww.subscribeCalibration(updateCameraCalibration)
xoff1,yoff1,xoff2,yoff2,margin = dww.getCalibration()
dww.start()

#####################
# bluetooth         #
#####################
ble = DWble.DWble().start()
ble.set_defaults()

#####################
# speech            #
#####################
speech = DWSpeech.DWSpeech()
speech.say("Welcome to DragonWally Sensor") 

#####################
# recognition logic #
#####################
dwrl = DWRecogLogic.DragonWallyRecognitionLogic(mode=2)
dwrl.subscribeRecognition(updateRecognition)
dwrl.start()

##############
# main logic #
##############
dwl = DWLogic.DragonWallyLogic(mode=1)
dwl.subscribeImage(updateWindowImage)
dwl.subscribeFace(updateFace)
dwl.setCameraCalibration(xoff1,yoff1,xoff2,yoff2,margin)
dwl.start()
while (dww.isRunning()):
  dwl.logic(module=0)
dwl.logic(module=1)


##############
# dummy loop #
##############
# loop over while program is running
while dww.isRunning():
 	# do something here	
	pass

###############
# termination #
############### 
dwrl.stop()
dwl.stop()
ble.stop()
print("DragonWally terminated")


