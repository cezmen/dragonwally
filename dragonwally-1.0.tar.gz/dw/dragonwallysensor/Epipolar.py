# Class Epipolar

import math

class Epipolar:
	def __init__(self,width=495):
		self.xleft = 0 
		self.yleft = 0 
		self.wleft = 0 
		self.hleft = 0 
		self.xright = 0 
                self.yright = 0 
                self.wright = 0 
                self.hright = 0 
		self.F = 337
		self.T = 41.0
		self.width = width

	def updateWidth(width):
		self.width = width 

	def setLeftFace(self,x,y,w,h,img=None):
		self.xleft = x 
                self.yleft = y 
                self.wleft = w 
                self.hleft = h
		self.imgleft = img 

        def setRightFace(self,x,y,w,h,img=None):
                self.xright = x - self.width 
                self.yright = y 
                self.wright = w
                self.hright = h 
		self.imgright = img

	def getZ(self):
		dx = math.fabs((self.xright+self.wright/2)-(self.xleft+self.wleft/2))
		# dy = math.fabs((self.yright+self.hright/2)-(self.yleft+self.hleft/2))
		# delta = math.sqrt(math.pow(dx,2.0)+math.pow(dy,2.0))
		if (dx != 0.0):
			self.Z = self.F * self.T / dx
		else:
			self.Z = 0.0 
		return self.Z

	def getFacesOrder(self,faces):
		if (faces[0][0] < self.width) and (faces[1][0] >= self.width):
		   return (0,1)
		elif (faces[1][0] < self.width) and (faces[0][0] >= self.width):
		   return (1,0)
		else:
		   return (-1,-1)


