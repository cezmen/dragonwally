#!/usr/bin/env python

################################################
# DWRecogLogic - DragonWally Recognition Logic #
################################################

import aws_helpers as ah
from PIL import Image
from os.path import join, dirname, realpath
from threading import Thread
import DWFaceIndex

#########
# Paths #
#########
dwrecog_file = 'dwrecogimage.jpg'
dwrecog_dir  = dirname(realpath(__file__))
dwrecog_path = join(dwrecog_dir,dwrecog_file)

#################################
# DragonWally Recognition Logic #
#################################

class DragonWallyRecognitionLogic:

	def __init__(self,mode=0):

	   # queue
	   self.image_queue = []

	   # callbacks
	   self.recognition_callbacks = []

	   # flags and variables
	   self.recognition_mode = mode
	   self.flagIsRunning = False
	   self.recognitionThreshold = 50.0

	   # face index
	   self.faceindex = DWFaceIndex.DragonWallyFaceIndex()

	   # aws
	   self.aws = ah.AwsHelper()

	def setThreshold(t):
	   self.recognitionThreshold = t

	def start(self):
	   self.flagIsRunning = True	   
	   print ("DWRecogLogic started")
 	   Thread(target=self.update,args=()).start()
	   return self

        def stop(self):
           print ("DWRecogLogic stopped")
           self.flagIsRunning = False

        def subscribeRecognition(self,callback):
           self.recognition_callbacks.append(callback)

	def save_image(self,img):
	   im = Image.fromarray(img)
	   im.save(dwrecog_path)

	def request(self,img):
	   if (len(self.image_queue) < 3):
	     self.image_queue.append(img)

	def try_recognition(self,dir,file,threshold):
	     flag = False
	     R = []
	     try:
                 R = self.aws.search_face_in_collection(dir,file,threshold)
                 flag = True
             except:
	     	 print ("AWS Rekognition Exception") 
                 flag= False

	     return (flag,R)
	
        ######################
        # Thread update loop #
        ######################
        def update(self):
           while (self.flagIsRunning == True):
		if (len(self.image_queue)):
		   ###########################
                   # Get an Image from Queue #
 		   ###########################
		   img = self.image_queue.pop()		
		   self.save_image(img)
		   ############################################
                   # Try to Recognize through AWS Rekognition #
		   ############################################
		   flag_success , R = self.try_recognition(dwrecog_dir,dwrecog_file,self.recognitionThreshold)		   	   
		   if ( flag_success and (len(R["FaceMatches"]) > 0) ):
		     for fn in self.recognition_callbacks:
		        filename  = R["FaceMatches"][0]["Face"]["ExternalImageId"]
		        id = R["FaceMatches"][0]["Face"]["ImageId"]
		        similarity = R["FaceMatches"][0]["Similarity"] 
			name = self.faceindex.getName(id)
		        fn(name,id,similarity)
		   else:
		     for fn in self.recognition_callbacks:
			fn("",0,0.0)


