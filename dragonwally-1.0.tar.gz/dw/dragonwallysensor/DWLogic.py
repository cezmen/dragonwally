#! /usr/bin/python

# DWLogic - DragonWally Logic

from DWCam import DragonWallyCamera
from FPS import FPS
import imutils
import cv2
import numpy as np
import Epipolar
from threading import Thread
from PIL import Image

#######################
# ancillary functions #
#######################

def color_swap(img):
	red,green,blue = img.T
	img = np.array([blue,green,red]).T
	return img

def detect_pattern(img,fc):
	gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
	faces = fc.detectMultiScale(gray,
                                    scaleFactor=1.25, # 1.05=precise , 1.4=fast
                                    minNeighbors=3)  # 3~6 are good values
	return faces

def draw_text(img,text1,text2,width,height):
	cv2.putText(img, "CAM{}".format(1),
                    (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                    0.6, (0, 255, 0), 2)
	cv2.putText(img, "CAM{}".format(2),
                    (width+10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                    0.6, (0, 255, 0), 2)
	cv2.putText(img, text1,
                    (10,height-10), cv2.FONT_HERSHEY_SIMPLEX,
                    1, (0, 255, 0), 2)
        cv2.putText(img, text2,
                    (width+10,height-10), cv2.FONT_HERSHEY_SIMPLEX,
                    1, (0, 255, 0), 2)


def fit_boundary(img,x,y,w,h):
	maxheight,maxwidth,c = img.shape
	xf = x if (x>0) else 0
	yf = y if (y>0) else 0
	wf = w if (x+w < maxwidth) else (maxwidth - x)
	hf = h if (y+h < maxheight) else (maxheight - y)
	print("%d %d (%d,%d,%d,%d) -> (%d,%d,%d,%d)"%(maxwidth,maxheight,x,y,w,h,xf,yf,wf,hf))
	return (xf,yf,wf,hf)


def save_image(img,path):
        im = Image.fromarray(img)
        im.save(path)

#####################
# DragonWally Logic #
#####################

################################################
# Thread Mode (mode=0) or Direct Mode (mode=1) # 
################################################
class DragonWallyLogic:

	def __init__(self,mode=0):
	   # running mode
	   self.mode = mode

	   # callbacks
	   self.image_callbacks = []
	   self.face_callbacks = []
	   
	   # flags
	   self.flagDetectEyes = False 
	   self.flagUseCorrelation = True
	   self.flagIsRunning = False

	   # created a *threaded* video stream, allow the camera sensor to warmup,
	   self.vs = [DragonWallyCamera(src=0,mode=0).start(),DragonWallyCamera(src=1,mode=0).start()]
	   self.setCameraCalibration(0,0,0,0,140)

	   # Video Frame Dimension and Scaling
	   self.updateFrameScale(4)

	   self.epi = Epipolar.Epipolar(width=self.framewidth)
           self.face_cascade = cv2.CascadeClassifier('./haarcascades/haarcascade_frontalface_default.xml')
           self.eye_cascade = cv2.CascadeClassifier('./haarcascades/haarcascade_eye.xml')

	   # Other variables
	   self.Subtitle = ["" , ""]
	
	def setSubtitle(self,id,text):
	   if (id in range(0,2)):
	     self.Subtitle[id] = text   

	def start(self):
	   self.flagIsRunning = True
	   self.fps = FPS().start()
	   print ("DWLogic started")

	   if (self.mode == 0):
	   	Thread(target=self.update,args=()).start()
	   else:
		# do nothing
		pass

	   return self
	
	def stop(self):
	   print ("DWLogic stopped")
	   self.flagIsRunning = False 

	def subscribeImage(self,callback):
	   self.image_callbacks.append(callback)

        def subscribeFace(self,callback):
           self.face_callbacks.append(callback)

	def setCameraCalibration(self,xoff1,yoff1,xoff2,yoff2,margin):
	   self.vs[0].setCalibration(int(xoff1),int(yoff1),int(margin))
           self.vs[1].setCalibration(int(xoff2),int(yoff2),int(margin))

	def updateFrameScale(self,scale):
           self.framescale = scale
           fw,fh = self.vs[0].getDimensions()
           self.framewidth = fw / scale 
           self.frameheight = fh / scale
	
	######################
        # Thread update loop #
        ######################
	def update(self):
	   while (self.flagIsRunning == True):
	      self.logic(module=0)
	   self.logic(module=1)			
	   
	
	def logic(self,module):
	   ##############################
	   # Module 0 (main loop logic) #
	   ##############################
	   if (module == 0):
		######################
                # Capture and Rotate #
                ######################
		bigframe = [imutils.rotate(self.vs[0].read(),angle=180),imutils.rotate(self.vs[1].read(),angle=180)]
                ######################
                # Scale down         #
                ######################
		frame = [imutils.resize(bigframe[0], width=self.framewidth),imutils.resize(bigframe[1], width=self.framewidth)]
                ######################
                # Combine            #
                ######################
		combframe = np.hstack([frame[0],frame[1]])
                ######################
                # Face Detection     #
                ######################
		faces = detect_pattern(combframe,self.face_cascade)
		combframe = np.array(combframe)
		##################
		# FACE CALLBACKS #
                ##################
                if (len(faces) > 0):
                   x,y,w,h = faces[0]
		   if (x < self.framewidth):
                      xs = x * self.framescale - 25
                      ys = y * self.framescale - 25
	              ws = w * self.framescale + 50
                      hs = h * self.framescale + 50
		      xs,ys,ws,hs = fit_boundary(bigframe[0],xs,ys,ws,hs)
                      miniframe = color_swap(bigframe[0][ys:ys+hs,xs:xs+ws])
		   else:
		      xs = (x - self.framewidth) * self.framescale - 25
                      ys = y * self.framescale - 25
                      ws = w * self.framescale + 50
                      hs = h * self.framescale + 50
		      xs,ys,ws,hs = fit_boundary(bigframe[1],xs,ys,ws,hs)
                      miniframe = color_swap(bigframe[1][ys:ys+hs,xs:xs+ws])		      

                   # miniframe = color_swap(combframe[y:y+h,x:x+w])
                   for fn in self.face_callbacks :
                     fn(miniframe)

                ################################
		# DRAW RECTANGLES AROUND FACES #
                ################################
		if (len(faces) > 0):
		   for (x,y,w,h) in faces:
           	      print("Face @ [x,y]=[%d,%d] [w,h]=[%d,%d]" % (x,y,w,h))
                      cv2.rectangle(combframe,(x,y),(x+w,y+h),(255,0,0),3)
		      if (self.flagDetectEyes == True):
		         miniframe = combframe[y:y+h,x:x+w]
		      	 eyes = detect_pattern(miniframe,self.eye_cascade)
		      	 for (ex,ey,ew,eh) in eyes:
		      	    cv2.circle(miniframe,(ex+ew/2,ey+eh/2),(ew+eh)/4,(255,0,0),3)

                #####################
		# EPIPOLAR GEOMETRY #
                #####################
		if (len(faces) == 2):
		      IL , IR = self.epi.getFacesOrder(faces)
		      if (self.flagUseCorrelation == True):
		         imgleft = combframe[faces[IL][1]:faces[IL][1]+faces[IL][3],faces[IL][0]:faces[IL][0]+faces[IL][2]]
		       	 imgright = combframe[faces[IR][1]:faces[IR][1]+faces[IR][3],faces[IR][0]:faces[IR][0]+faces[IR][2]]
		      else:
			 imgleft = None
			 imgright = None
	
		      self.epi.setLeftFace(faces[IL][0],faces[IL][1],faces[IL][2],faces[IL][3],imgleft)
		      self.epi.setRightFace(faces[IR][0],faces[IR][1],faces[IR][2],faces[IR][3],imgright)


		      self.Subtitle[0] = infoText = "Z={:.0f} mm".format(self.epi.getZ())
		else:
		      self.Subtitle[0] = ""

		draw_text(combframe,self.Subtitle[0],self.Subtitle[1],self.framewidth,self.frameheight)

                ###################
		# IMAGE CALLBACKS #
                ###################
		img = imutils.resize(color_swap(combframe),800)
	  	for fn in self.image_callbacks:
		   fn(img)
		save_image(img,"dwmainimage.jpg")
                ##########################
		# update the FPS counter #
                ##########################
		self.fps.update()
	   #######################################
	   # Module 1 (finish and cleanup logic) #
	   #######################################
	   elif (module==1):
                ###############
	   	# stop FPS    #
                ############### 
	   	self.fps.stop()
	   	print("[INFO] elasped time: {:.2f}".format(self.fps.elapsed()))
	   	print("[INFO] approx. FPS: {:.2f}".format(self.fps.fps()))
                ###############
	   	# CLEANUP     #
                ###############
	   	self.vs[0].stop()
	   	self.vs[1].stop()

